const changeText = () => {
  // Выбираем элемент на странице, и меняем содержимое нужного поля
  document.getElementsByClassName('block4')[0].textContent = "Chumakova";
  document.getElementsByClassName('block5')[0].textContent = "Elizaveta";
  document.getElementsByClassName('block6')[0].textContent = "Alexandrovna";
  document.getElementsByClassName('block8')[0].textContent = "I.I.MMIII";
}
